package com.cg.dao;

import java.util.List;

import com.cg.dto.BookingDTO;
import com.cg.dto.RoomDTO;

public interface HotelEmployeeDAO {
	
	List<RoomDTO> fetchRoomsByHotelId(int hotelId);
	List<BookingDTO> fetchBookingdetails(int hotelId);
	

}
