package com.cg.hbms.exception;

public class NoRoomsAvailableException  extends Exception {

	public NoRoomsAvailableException()
	{
	
	}
	
 public NoRoomsAvailableException(String message)
{
super(message);
}
 public NoRoomsAvailableException(String message,Throwable t)
{
	 super(message,t);

}
@Override
public String toString() {
	return "NoRoomsAvailable ";
}
 
 
}
