package com.cg.hbms.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.dto.UserDto;

public class AdminDaoImpl implements AdminDao{

	
	
	
	@Override
	public boolean authenticate(String adminUsername, String password){
		
		for (Entry<Integer, UserDto> user : StaticDb.getUserData().entrySet())  
            if(user.getValue().getUserName().equals(adminUsername) && user.getValue().getPassword().equals(password) && user.getValue().getRole().equals("admin"))
            {
            	return true;
            }
		return false;
	}
	@Override
	public String addHotel(String hotelName, String hotelCity, String hotelAddress, String hotelDescription,
			String strHotelAvgRatePerNight, String hotelPhone1, String hotelPhone2, String strHotelRating,
			String hotelEmail) {
		
		Double hotelAvgRatePerNight = Double.parseDouble(strHotelAvgRatePerNight);
		Double hotelRating = Double.parseDouble(strHotelRating);
HotelDto hotel = new HotelDto(hotelName,hotelCity, hotelAddress, hotelDescription,
			hotelAvgRatePerNight, hotelPhone1, hotelPhone2, hotelRating,
			hotelEmail);
		StaticDb.getHotelData().put(hotel.getHotelId(),hotel);
		
		return "New Hotel Added [ Hotel ID : "+hotel.getHotelId()+" ]\n";
	}

	@Override
	public String delHotel(String strHotelId) {
		Integer hotelId = Integer.parseInt(strHotelId);
		if(StaticDb.getHotelData().containsKey(hotelId))
		{
			StaticDb.getHotelData().remove(hotelId);
			Iterator<Integer> it = StaticDb.getRoomData().keySet().iterator();
			List<Integer> rooms = new ArrayList<Integer>();
			while (it.hasNext()) {
				Integer roomIdKey = it.next();
				if (StaticDb.getRoomData().get(roomIdKey).getHotelId().equals(hotelId)) {
					rooms.add(StaticDb.getRoomData().get(roomIdKey).getRoomId());
					it.remove();
				}
			}
			return "Hotel Deleted [ Rooms belonging to hotel ID: "+hotelId+" also deleted ]\n"
					+ "Rooms Deleted "+rooms;
		}
			return "Hotel with given Id does not exist!!..";
	}
	@Override
	public String addRoom(String strHotelId,String roomNo, String roomType, String strPerNightRate) {
		
		Integer hotelId = Integer.parseInt(strHotelId);
		Double perNightRate = Double.parseDouble(strPerNightRate);
		RoomDto room = new RoomDto(hotelId,roomNo, roomType, perNightRate, true);
		StaticDb.getRoomData().put(room.getRoomId(),room);
		return "New Room added [ Hotel ID: "+room.getHotelId()+" ... Room ID: "+room.getRoomId()+" ]";
	}
	@Override
	public String delRoom(String strRoomId) {
		Integer roomId=Integer.parseInt(strRoomId);
		if(StaticDb.getRoomData().containsKey(roomId))
		{
			StaticDb.getRoomData().remove(roomId);
			return "Room Deleted [ Room ID: "+roomId+" ]";
		}
		return "Room with given ID does not exist";
	}
	@Override
	public List<HotelDto> viewListOfHotels() {
		List<HotelDto> listOfHotels = new ArrayList<HotelDto>(StaticDb.getHotelData().values());
		
		return listOfHotels;
	}
	@Override
	public List<BookingDto> viewBookingsByHotel(String strHotelId) {
		Integer hotelId = Integer.parseInt(strHotelId);
		List<BookingDto> bookingsByHotel = new ArrayList<BookingDto>();
		for (Entry<Integer, BookingDto> booking : StaticDb.getBookingData().entrySet())  
		{
			if(hotelId.equals(booking.getValue().getHotelId()))
				{
				bookingsByHotel.add(booking.getValue());
				}
		}
		return bookingsByHotel;
	}
	@Override
	public List<BookingDto> viewBookingsByDate(String strDate) {
		LocalDate date = LocalDate.parse(strDate);
		List<BookingDto> bookingsByDate = new ArrayList<BookingDto>();
		for (Entry<Integer, BookingDto> booking : StaticDb.getBookingData().entrySet())  
		{
			if((date.isEqual(booking.getValue().getBookedFrom()) || date.isAfter(booking.getValue().getBookedFrom())) && (date.isEqual(booking.getValue().getBookedTo()) || date.isBefore(booking.getValue().getBookedTo())))
			{
				bookingsByDate.add(booking.getValue());
			}
		}
		return bookingsByDate;
	}
	@Override
	public List<UserDto> viewListOfCustomers() {
		List<UserDto> listOfCustomers = new ArrayList<UserDto>();
		for (Entry<Integer, UserDto> user : StaticDb.getUserData().entrySet())  
		{
			if(user.getValue().getRole().equals("user"))
			{
				listOfCustomers.add(user.getValue());
			}
		}
		return listOfCustomers;
	}
	@Override
	public List<UserDto> viewListOfHotelEmployees() {
		List<UserDto> listOfHotelEmployees = new ArrayList<UserDto>();
		for (Entry<Integer, UserDto> user : StaticDb.getUserData().entrySet())  
		{
			if(user.getValue().getRole().equals("HE"))
			{
				listOfHotelEmployees.add(user.getValue());
			}
		}
		return listOfHotelEmployees;
	}

	@Override
	public String updateHotelAddress(String strHotelId,String hotelAddress) {
		Integer hotelId=Integer.parseInt(strHotelId);
		if(!(StaticDb.getHotelData().containsKey(hotelId)))
		{
			return "Hotel with given ID [ "+hotelId+" ] does not exist...\n";
		}
		else
		{
			StaticDb.getHotelData().get(hotelId).setHotelAddress(hotelAddress);
			return "Hotel Address updated for Hotel ID [ "+hotelId+" ]";
		}

	}
	@Override
	public String updateHotelDescription(String strHotelId, String hotelDescription) {
		Integer hotelId=Integer.parseInt(strHotelId);
		if(!(StaticDb.getHotelData().containsKey(hotelId)))
		{
			return "Hotel with given ID [ "+hotelId+" ] does not exist...\n";
		}
		else
		{
			StaticDb.getHotelData().get(hotelId).setHotelDescription(hotelDescription);;
			return "Hotel Description updated for Hotel ID [ "+hotelId+" ]";
		}
	}
	@Override
	public String updateHotelAvgRatePerNight(String strHotelId, String strHotelAvgRatePerNight) {
		Integer hotelId=Integer.parseInt(strHotelId);
		if(!(StaticDb.getHotelData().containsKey(hotelId)))
		{
			return "Hotel with given ID [ "+hotelId+" ] does not exist...\n";
		}
		else
		{
			Double hotelAvgRatePerNight=Double.parseDouble(strHotelAvgRatePerNight);
			StaticDb.getHotelData().get(hotelId).setHotelAvgRatePerNight(hotelAvgRatePerNight);
			return "Hotel Average Rate Per Night updated for Hotel ID [ "+hotelId+" ]";
		}
	}
	@Override
	public String updateHotelPhone(String strHotelId, String hotelPhone1) {
		Integer hotelId=Integer.parseInt(strHotelId);
		if(!(StaticDb.getHotelData().containsKey(hotelId)))
		{
			return "Hotel with given ID [ "+hotelId+" ] does not exist...\n";
		}
		else
		{
			StaticDb.getHotelData().get(hotelId).setHotelPhone1(hotelPhone1);
			return "Hotel Phone Number updated for Hotel ID [ "+hotelId+" ]";
		}
	}
	@Override
	public String updateHotelEmail(String strHotelId, String hotelEmail) {
		Integer hotelId=Integer.parseInt(strHotelId);
		if(!(StaticDb.getHotelData().containsKey(hotelId)))
		{
			return "Hotel with given ID [ "+hotelId+" ] does not exist...\n";
		}
		else
		{
			StaticDb.getHotelData().get(hotelId).setHotelEmail(hotelEmail);
			return "Hotel Email updated for Hotel ID [ "+hotelId+" ]";
		}
	}
	@Override
	public String updateRoomType(String strRoomId, String roomType) {
		Integer roomId=Integer.parseInt(strRoomId);
		if(!(StaticDb.getRoomData().containsKey(roomId)))
		{
			return "Room with Given ID [ "+roomId+" ] does not exist...\n";
		}
		else
		{
			StaticDb.getRoomData().get(roomId).setRoomType(roomType);
			return "Room Type update for Room ID [ "+roomId+" ] ";
		}
	}
	@Override
	public String updateRoomPerNightRate(String strRoomId, String strPerNightRate) {
		Integer roomId=Integer.parseInt(strRoomId);
		Double perNightRate=Double.parseDouble(strPerNightRate);
		if(!(StaticDb.getRoomData().containsKey(roomId)))
		{
			return "Room with Given ID [ "+roomId+" ] does not exist...\n";
		}
		else
		{
			StaticDb.getRoomData().get(roomId).setPerNightRate(perNightRate);
			return "Room Tarrif updated for Room ID [ "+roomId+" ] ";
		}
	}
	@Override
	public String updateRoomAvailability(String strRoomId, String strAvailability) {
		Integer roomId=Integer.parseInt(strRoomId);
		Boolean availability=null;
		if(strAvailability.equals("1"))
		{
			availability=true;
		}
		else if(strAvailability.equals("0"))
		{
			availability=false;
		}
		if(!(StaticDb.getRoomData().containsKey(roomId)))
		{
			return "Room with Given ID [ "+roomId+" ] does not exist...\n";
		}
		else
		{
			StaticDb.getRoomData().get(roomId).setAvailability(availability);
			return "Room Availabilty updated for Room ID [ "+roomId+" ] ";
		}
	}




	

}
