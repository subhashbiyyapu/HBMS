package com.cg.hbms.ui;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.exception.NoRoomsAvailableException;
import com.cg.hbms.service.AdminService;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.HotelEmployeeService;
import com.cg.hbms.service.HotelEmployeeServiceImpl;
import com.cg.hbms.service.Validation;
import com.cg.hbms.service.ValidationImpl;

public class Ui {

	static LocalDate getDate(Scanner sc) {
		boolean dateValid = true;
		int year,month,day;
		Scanner sc1 = sc;
		do
		{
			if(dateValid==false)
		
			{
				System.out.println("invalid date");
			}
		System.out.println("enter year");
		 year = sc1.nextInt();

		System.out.println("enter month  from 1 to 12");
		 month = sc1.nextInt();

		System.out.println("enter day  from 1 to 31");
		 day = sc1.nextInt();
          Validation valid=new ValidationImpl();
          dateValid=valid.isValidDate(year, month, day);
		}while(dateValid==false);


		LocalDate ld = LocalDate.of(year, month, day);

		return ld;
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int mainOption;
		char mainChoice = 'y';

		while (mainChoice == 'y') {
			System.out.println("----------------WELCOME TO HBMS----------------");
			System.out.println("\n1. Login as Customer" + "\n2. Login as Hotel Employee" + "\n3. Login as Admin"
					+ "\n4. New user? Register" + "\n5. Exit" + "\n\nSelect option: ");
			mainOption = sc.nextInt();
			sc.nextLine();

			switch (mainOption) {
			case 1:
				System.out.println("User Login coming soon...");
				break;

			case 2:
				System.out.println("Hotel Employee Login ");
				HotelEmployeeService he = new HotelEmployeeServiceImpl();
				String userName = null;
				int hotelId;
				int userId;
				int heFlag = 1;
				HashMap<Integer, RoomDto> roomHashMap = new HashMap<Integer, RoomDto>();
				int choice;
				int roomChoice, roomTypeI, passwordChangeChoice;Double amount;
				int numDays = 1;
				boolean validToDateFlag = true, validFromDateFlag = true, tryAgainFlag = true,changePasswordFlag = true;
				boolean successLoginFlag = false;
				LocalDate fromDate;
				LocalDate toDate;
				String loginData = null;
				boolean roomTypeChoice=false;

				String password, oldPassword, newPassword;

				while (tryAgainFlag == true) {
					
					System.out.println("Enter user Name");
					userName = sc.nextLine();

					System.out.println("Enter Password");
					password = sc.nextLine();

					loginData = he.authenticateHotelEmployee(userName, password);
					if (loginData.equals("incorrectPassword")) {
						tryAgainFlag = true;
						System.out.println(loginData);
					} else if (loginData.equals("invalidUser")) {
						tryAgainFlag = true;
						System.out.println(loginData);
					} else {
						tryAgainFlag = false;
						successLoginFlag = true;
					}

					if (tryAgainFlag == true) {
						System.out.println("would you like try again\n1.try again \n2.exit");
						if (sc.nextInt() != 1) {
							successLoginFlag = false;
							tryAgainFlag = false;

						}
					}
				}

				if (successLoginFlag == true) {

					userId = he.fetchUserIdBasedOnName(userName);
					hotelId = Integer.parseInt(loginData);

					do {
						System.out.println("----------------WELCOME  HotelEmployee----------------");
						System.out.println("1.Display all the rooms \n" + "2.Book a room \n"
								+ "3.View booking transactions\n" + "4.Change password\n" + "5.Exit  ");
						choice = sc.nextInt();

						switch (choice) {

						case 1:
							System.out.println(" see the status of the rooms");

							do {

								do {
									if (validFromDateFlag == false)
										System.out.println("Invalid Date ");
									else if (numDays == 0)
										System.out.println("booking is allowed for only 7 days ");

									System.out.println("enter FROM date");
									fromDate = getDate(sc);
									validFromDateFlag = he.validatefromDate(fromDate);

								} while (validFromDateFlag == false);

								do {
									if (validToDateFlag == false)
										System.out.println("TO date has to be after FROM date");

									System.out.println("Enter TO date");
									toDate = getDate(sc);
									numDays = he.validateNoOfDays(fromDate, toDate);
									validToDateFlag = he.validateDate(fromDate, toDate);

								} while (validToDateFlag == false);

							} while (numDays == 0);

							roomHashMap = he.displayRooms(hotelId, LocalDate.of(2020, 3, 13),
									LocalDate.of(2020, 3, 14));
							Set<Entry<Integer, RoomDto>> entrySet = roomHashMap.entrySet();
							System.out.printf("%20s%20s%20s%n", "Room No", "Availability", "RoomType");

							for (Entry entry : entrySet) {
								RoomDto room = new RoomDto();
								room = (RoomDto) entry.getValue();

								System.out.printf("%20s%20s%20s%n", room.getRoomNo(), room.isAvailability(),
										room.getRoomType());

							}

							break;
						case 2:
							try {

							
								do
								{
									if(roomTypeChoice==true)
									{
										System.out.println("invalid option");
									}
									
								
								System.out.println("enter Type of the room\n1.AC\n2.NonAC");
								roomTypeI = sc.nextInt();
								if(roomTypeI!=1 && roomTypeI!=2)
								{
									roomTypeChoice=true;
								}
								else
								{
									roomTypeChoice=false;
								}
								}while(roomTypeChoice==true);
								

								do {

									do {
										if (validFromDateFlag == false)
											System.out.println("Invalid Date ");
										else if (numDays == 0)
											System.out.println("booking is allowed for only 7 days ");

										System.out.println("enter FROM date");
										fromDate = getDate(sc);
										validFromDateFlag = he.validatefromDate(fromDate);
									} while (validFromDateFlag == false);

									do {
										if (validToDateFlag == false)
											System.out.println("TO date has to be after FROM date");

										System.out.println("Enter TO date");
										toDate = getDate(sc);
										numDays = he.validateNoOfDays(fromDate, toDate);
										validToDateFlag = he.validateDate(fromDate, toDate);

									} while (validToDateFlag == false);

								} while (numDays == 0);

								roomHashMap = he.displayRoomsBasedOnType(hotelId, fromDate, toDate, roomTypeI);

								System.out.println("Rooms available are ::::::");
								Set<Entry<Integer, RoomDto>> entrySet1 = roomHashMap.entrySet();
								System.out.printf("%20s%20s%n", "Room No", "Availability");

								for (Entry entry : entrySet1) {
									RoomDto room = new RoomDto();
									room = (RoomDto) entry.getValue();
									System.out.printf("%20s%20s%n", room.getRoomId(), room.isAvailability());
								}

								while (true) {
									System.out.println("Enter room Id");
									roomChoice = sc.nextInt();

									RoomDto tempRoom = roomHashMap.get(roomChoice);
									if (tempRoom == null) {
										System.out.println("invalid room number");
									} else {
										if (tempRoom.isAvailability() == true) {
											amount = tempRoom.getPerNightRate();
											break;
										} else {
											System.out.println("room is not available");
										}
									}
								}

								System.out.println("enter no of adults");
								int noOfAdult = sc.nextInt();

								System.out.println("enter no of children");
								int noOfChildren = sc.nextInt();

								amount = numDays * amount;
								System.out.println("Total    Amount" + amount);

								BookingDto bookDto = new BookingDto(roomChoice, hotelId, userId, fromDate, toDate,
										noOfAdult, noOfChildren, amount);
								String bookingStatus = he.addBookingRecord(bookDto);
								System.out.println(bookingStatus);
								System.out.println(bookDto);

							} catch (NoRoomsAvailableException e) {
								System.out.println(e);
							}
							break;
						case 3:
							System.out.println("Transactions of this hotel ::::::::");
							List<BookingDto> bookingList = he.displayTransactionsOfThehotelEmployee(hotelId, userId);
							Iterator<BookingDto> itr = bookingList.iterator();
							BookingDto bookObj;
							while (itr.hasNext()) {
								bookObj = (BookingDto) itr.next();
								System.out.println(bookObj);
							}
							break;

						case 4:

							System.out.println("Change the password");

							do {
								System.out.println("Enter the old password");
								oldPassword = sc.next();
								changePasswordFlag = he.validatePassword(userId, oldPassword);
								if (changePasswordFlag == false) {
									System.out.println("incorrect password \n TYPE \n1.to try again \n 2.to exit");
									passwordChangeChoice = sc.nextInt();
									if (passwordChangeChoice != 1) {

									}
									break;

								}
							} while (changePasswordFlag == false);

							if (changePasswordFlag == true) {
								System.out.println("Enter the new  password");
								newPassword = sc.next();
								if (he.changePassword(userId, newPassword)) {
									System.out.println("Password Changed Successfully");
								} else {
									System.out.println("Password changing Failed");
								}

							}

							break;

						default:
							System.out.println("exiting from Hotel Employee");
							heFlag = 2;

							break;
						}

					} while (heFlag == 1);

				}

				break;

			case 3:
				char adminLoginChoice = 'y';
				AdminService adminService = new AdminServiceImpl();
				Validation adminValidate = new ValidationImpl();
				while (adminLoginChoice == 'y') {

					System.out.println("Enter Username: ");
					String adminUsername = sc.nextLine();
					System.out.println("Enter Admin password: ");
					String adminPassword = sc.nextLine();

					boolean isValidLoginCredentials = adminService.authenticate(adminUsername, adminPassword);
					if (isValidLoginCredentials) {
						System.out.println("Login Successful");
						String adminOption;
						char adminChoice = 'y';
						System.out.println("\n-----WELCOME ADMIN-----\nPlease select on option:\n");
						while (adminChoice == 'y') {
							System.out.println(
									"1. Add Hotel\n" + "2. Delete Hotel\n" + "3. Update Hotel\n" + "4. Add Room\n"
											+ "5. Delete Room\n" + "6. Update Room\n" + "7. View List of Hotels\n"
											+ "8. View List of Customers\n" + "9. View Bookings for a spcific hotel\n"
											+ "10. View Bookings of a specific date\n" + "11. Back to Home Page\n"
											+ "12. Exit" + "\nEnter choice (1-9) : ");
							adminOption = sc.nextLine();
							String strHotelId = null;
							String hotelName = null;
							String hotelCity = null;
							String hotelAddress = null;
							String hotelDescription = null;
							String strHotelAvgRatePerNight = null;
							String hotelPhone1 = null;
							String hotelPhone2 = null;
							String strHotelRating = null;
							String hotelEmail = null;
							String strRoomId = null;
							String roomType = null;
							String strPerNightRate = null;
							String roomNo = null;
							String strAvailability = null;
							String strDate = null;
							boolean isValidInput;
							switch (adminOption) {
							case "1":
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Hotel Name : ");
									hotelName = sc.nextLine();
									isValidInput = adminValidate.isValidAlphanumericInput(hotelName);
									if (hotelName.length() > 20 || !isValidInput) {
										System.out.println(
												"Hotel Name can only contain alphabets, digits & spaces...(Max Length = 20)\n");
										isValidInput = false;
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter City : ");
									hotelCity = sc.nextLine();
									isValidInput = adminValidate.isValidAlphabeticInput(hotelCity);
									if (hotelCity.length() > 10 || !isValidInput) {
										System.out.println(
												"City Name can only contain alphabets...(Max Allowed Length = 10)\n");
										isValidInput = false;
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Hotel Address : ");
									hotelAddress = sc.nextLine();
									isValidInput = adminValidate.isValidAlphanumericInput(hotelAddress);
									if (hotelAddress.length() > 25 || !isValidInput) {
										System.out.println(
												"Hotel Address can only contain alphabets, Digits and spaces...(Max Allowed Length = 25)\n");
										isValidInput = false;
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Discription : ");
									hotelDescription = sc.nextLine();
									isValidInput = adminValidate.isValidAlphanumericInput(hotelDescription);
									if (hotelDescription.length() > 50 || !isValidInput) {
										System.out.println(
												"Descrition can only contain alphabtes, digits and spaces...(Max Allowed Length=50)\n");
										isValidInput = false;
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Average Rate per night : ");
									strHotelAvgRatePerNight = sc.nextLine();
									isValidInput = adminValidate.isValidAmount(strHotelAvgRatePerNight);
									if (!isValidInput) {
										System.out.println("Please Enter a Numerical value...\n");
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Hotel Phone Number : ");
									hotelPhone1 = sc.nextLine();
									isValidInput = adminValidate.isValidNumericInput(hotelPhone1);
									if (hotelPhone1.length() != 10 || !isValidInput) {
										System.out.println(isValidInput);
										System.out.println("Invalid Phone Number...\n");
										isValidInput = false;
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Alternate Phone Number : ");
									hotelPhone2 = sc.nextLine();
									isValidInput = adminValidate.isValidNumericInput(hotelPhone2);
									if (hotelPhone1.length() != 10 || !isValidInput) {
										System.out.println(isValidInput);
										System.out.println("Invalid Phone Number...\n");
										isValidInput = false;
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Hotel Rating (out of 5): ");
									strHotelRating = sc.nextLine();
									isValidInput = adminValidate.isValidRating(strHotelRating);
									if (!isValidInput) {
										System.out.println("Please Enter a decimal value between 0 to 5...\n");
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Hotel Email ID : ");
									hotelEmail = sc.nextLine();
									isValidInput = adminValidate.isValidEmailId(hotelEmail);
									if (!isValidInput) {
										System.out.println("Invalid Email address...\n");
									}
								}
								System.out.println(adminService.addHotel(hotelName, hotelCity, hotelAddress,
										hotelDescription, strHotelAvgRatePerNight, hotelPhone1, hotelPhone2,
										strHotelRating, hotelEmail));
								break;

							case "2":
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput = adminValidate.isValidNumericInput(strHotelId);
									if (strHotelId.length() != 3 || !isValidInput) {
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput = false;
									}
								}
								System.out.println(adminService.delHotel(strHotelId));
								sc.nextLine();
								break;

							case "3":
								String updateHotelOption;
								char updateHotelChoice = 'y';
								while (updateHotelChoice == 'y') {
									isValidInput = false;
									while (!isValidInput) {
										System.out.println("Enter Hotel ID: ");
										strHotelId = sc.nextLine();
										isValidInput = adminValidate.isValidNumericInput(strHotelId);
										if (strHotelId.length() != 3 || !isValidInput) {
											System.out.println("Hotel ID can only be numeric 3 digit value...\n");
											isValidInput = false;
										}
									}
									System.out.println("\nSelect Field to update\n" + "1. Update Hotel Address\n"
											+ "2. Update Hotel Description\n" + "3. Update Hotel Tarrif\n"
											+ "4. Update Hotel Phone Number\n" + "5. Update Hotel Email Address\n"
											+ "6. Go Back to Menu\n" + "Select Option: ");
									updateHotelOption = sc.nextLine();
									switch (updateHotelOption) {
									case "1":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter New Hotel Address : ");
											hotelAddress = sc.nextLine();
											isValidInput = adminValidate.isValidAlphanumericInput(hotelAddress);
											if (hotelAddress.length() > 25 || !isValidInput) {
												System.out.println(
														"Hotel Address can only contain alphabets, Digits and spaces...(Max Allowed Length = 25)\n");
												isValidInput = false;
											}
										}
										System.out.println(adminService.updateHotelAddress(strHotelId, hotelAddress));
										break;
									case "2":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter New Discription : ");
											hotelDescription = sc.nextLine();
											isValidInput = adminValidate.isValidAlphanumericInput(hotelDescription);
											if (hotelDescription.length() > 50 || !isValidInput) {
												System.out.println(
														"Descrition can only contain alphabtes, digits and spaces...(Max Allowed Length=50)\n");
												isValidInput = false;
											}
										}
										System.out.println(
												adminService.updateHotelDescription(strHotelId, hotelDescription));

										break;
									case "3":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter New Tarrif : ");
											strHotelAvgRatePerNight = sc.nextLine();
											isValidInput = adminValidate.isValidAmount(strHotelAvgRatePerNight);
											if (!isValidInput) {
												System.out.println("Please Enter a Numerical value...\n");
											}
										}
										System.out.println(adminService.updateHotelAvgRatePerNight(strHotelId,
												strHotelAvgRatePerNight));

										break;
									case "4":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter New Phone Number : ");
											hotelPhone1 = sc.nextLine();
											isValidInput = adminValidate.isValidNumericInput(hotelPhone1);
											if (hotelPhone1.length() != 10 || !isValidInput) {
												System.out.println(isValidInput);
												System.out.println("Invalid Phone Number...\n");
												isValidInput = false;
											}
										}
										System.out.println(adminService.updateHotelPhone(strHotelId, hotelPhone1));

										break;
									case "5":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter New Hotel Email ID : ");
											hotelEmail = sc.nextLine();
											isValidInput = adminValidate.isValidEmailId(hotelEmail);
											if (!isValidInput) {
												System.out.println("Invalid Email address...\n");
											}
										}
										System.out.println(adminService.updateHotelEmail(strHotelId, hotelEmail));
										break;
									case "6":
										updateHotelChoice = 'n';
										break;
									default:
										System.out.println("Invalid Selection...\n");
										break;
									}
									break;
								}
								break;
							case "4":
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput = adminValidate.isValidNumericInput(strHotelId);
									if (strHotelId.length() != 3 || !isValidInput) {
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput = false;
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Room Number");
									roomNo = sc.nextLine();
									isValidInput = adminValidate.isValidRoomNumber(roomNo);
									if (!isValidInput) {
										System.out.println("Room Number can only contain Alphabets & Digits...\n");
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Room Type (Ac / NonAc) : ");
									roomType = sc.nextLine();
									if (roomType.equals("Ac") || roomType.equals("NonAc")) {
										isValidInput = true;

									} else {
										System.out.println("Please Enter a Valid Room Type...(Ac / NonAc)\n");
									}
								}
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Rate per night : ");
									strPerNightRate = sc.nextLine();
									isValidInput = adminValidate.isValidAmount(strPerNightRate);
									if (!isValidInput) {
										System.out.println("Please Enter a Numerical value...\n");
									}
								}
								System.out.println(adminService.addRoom(strHotelId, roomNo, roomType, strPerNightRate));
								break;

							case "5":
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Room ID : ");
									strRoomId = sc.nextLine();
									isValidInput = adminValidate.isValidNumericInput(strRoomId);
									if (strRoomId.length() != 4 || !isValidInput) {
										System.out.println("Room ID can only be numeric 4 digit value...\n");
										isValidInput = false;
									}
								}
								System.out.println(adminService.delRoom(strRoomId));
								break;

							case "6":
								String updateRoomOption;
								char updateRoomChoice = 'y';
								while (updateRoomChoice == 'y') {
									isValidInput = false;
									while (!isValidInput) {
										System.out.println("Enter Room ID: ");
										strRoomId = sc.nextLine();
										isValidInput = adminValidate.isValidNumericInput(strRoomId);
										if (strRoomId.length() != 4 || !isValidInput) {
											System.out.println("Room ID can only be numeric 4 digit value...\n");
											isValidInput = false;
										}
									}

									System.out.println("Select Field to update\n" + "1. Update Room Type\n"
											+ "2. Update Room Tarrif\n" + "3. Update Room Availability\n"
											+ "Select Option: ");
									updateRoomOption = sc.nextLine();
									switch (updateRoomOption) {
									case "1":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter Room Type (Ac / NonAc) : ");
											roomType = sc.nextLine();
											if (roomType.equals("Ac") || roomType.equals("NonAc")) {
												isValidInput = true;

											} else {
												System.out.println("Please Enter a Valid Room Type...(Ac / NonAc)\n");
											}
										}
										System.out.println(adminService.updateRoomType(strRoomId, roomType));
										updateRoomChoice = 'n';
										break;
									case "2":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter New Tarrif : ");
											strPerNightRate = sc.nextLine();
											isValidInput = adminValidate.isValidAmount(strPerNightRate);
											if (!isValidInput) {
												System.out.println("Please Enter a Numerical value...\n");
											}
										}
										System.out.println(
												adminService.updateRoomPerNightRate(strRoomId, strPerNightRate));
										updateRoomChoice = 'n';
										break;
									case "3":
										isValidInput = false;
										while (!isValidInput) {
											System.out.println("Enter Room Availabilty ( 1/0 ): ");
											strAvailability = sc.nextLine();
											isValidInput = (strAvailability.equals("1") || strAvailability.equals("0"));
											if (!isValidInput) {
												System.out.println("Invalid Choice...Please Choose: \n" + "1: Available"
														+ "0: Unavilable");
											}
										}
										System.out.println(
												adminService.updateRoomAvailability(strRoomId, strAvailability));
										updateRoomChoice = 'n';
										break;

									default:
										System.out.println("Invalid Selection...\n");
										break;
									}
									break;
								}
								break;
							case "7":
								if (adminService.viewListOfHotels().isEmpty()) {
									System.out.println("NO HOTELS FOUND!!..\n");
								} else {
									System.out.println("***List of Hotels***\n" + adminService.viewListOfHotels());
								}

								break;

							case "8":
								if (adminService.viewListOfCustomers().isEmpty()) {
									System.out.println("NO CUSTOMERS FOUND!!..\n");
								} else {
									System.out
											.println("***List of Customers***\n" + adminService.viewListOfCustomers());
								}
								break;

							case "9":
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput = adminValidate.isValidNumericInput(strHotelId);
									if (strHotelId.length() != 3 || !isValidInput) {
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput = false;
									}
								}
								if (adminService.viewBookingsByHotel(strHotelId).isEmpty()) {
									System.out.println("No bookings found for given Hotel ID " + strHotelId);
								} else {
									System.out.println("Bookings for Hotel ID: " + strHotelId);
									System.out.println(adminService.viewBookingsByHotel(strHotelId));
								}
								break;
							case "10":
								isValidInput = false;
								while (!isValidInput) {
									System.out.println("Enter Date (yyyy-mm-dd) : ");
									strDate = sc.nextLine();
									isValidInput = adminValidate.isValidDate(strDate);
									if (!isValidInput) {
										System.out.println("Invalid Date. Check Input Format!!..\n");
									}
								}
								if (adminService.viewBookingsByDate(strDate).isEmpty()) {
									System.out.println("No Bookings found for given Date " + strDate + "\n");
								} else {
									System.out.println("Bookings for Date " + strDate);
									System.out.println(adminService.viewBookingsByDate(strDate) + "\n");
								}
								break;

							case "11":
								adminChoice = 'n';
								adminLoginChoice = 'n';
								break;
							case "12":
								adminChoice = 'n';
								adminLoginChoice = 'n';
								mainChoice = 'n';
								System.out.println("Thank you for using HBMS");
								break;
							default:
								System.out.println("\nInvalid Selection!..Select Again\n");
								break;
							}
						}
					} else {
						System.out.println("Invalid Login Credentials!..\n");
						System.out.println("\nPress 0 to Go back to home page"
								+ "\nPress any other digit to try again..." + "\n\nSelect option");
						int tryLogin = sc.nextInt();
						sc.nextLine();
						if (tryLogin == 0) {
							adminLoginChoice = 'n';
						}
					}
				}
				break;
			case 4:
				System.out.println("Registeration page coming soon...");
				break;
			case 5:
				System.out.println("Thank you");
				mainChoice = 'n';
				break;
			default:
				System.out.println("Invalid Selection!! Select Again\n");
				break;
			}
		}
		sc.close();
	}

}
