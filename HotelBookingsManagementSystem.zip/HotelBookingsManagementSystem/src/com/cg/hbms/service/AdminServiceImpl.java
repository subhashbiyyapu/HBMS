package com.cg.hbms.service;
import java.util.List;

import com.cg.hbms.dao.AdminDao;
import com.cg.hbms.dao.AdminDaoImpl;
import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.UserDto;

public class AdminServiceImpl implements AdminService{

	AdminDao adminDao = new AdminDaoImpl();


	
	@Override
	public boolean authenticate(String adminUsername, String password) {
		
		return adminDao.authenticate(adminUsername,password);
	}


	@Override
	public String addHotel(String hotelName, String hotelCity, String hotelAddress, String hotelDescription,
			String strHotelAvgRatePerNight, String hotelPhone1, String hotelPhone2, String strHotelRating,
			String hotelEmail) {
		
		return adminDao.addHotel(hotelName, hotelCity, hotelAddress, hotelDescription, strHotelAvgRatePerNight, hotelPhone1, hotelPhone2, strHotelRating, hotelEmail);
	}


	@Override
	public String delHotel(String strHotelId) {
		return adminDao.delHotel(strHotelId);
	}


	@Override
	public String addRoom(String strHotelId, String RoomNo, String roomType, String strPerNightRate) {
		return adminDao.addRoom(strHotelId,RoomNo, roomType, strPerNightRate);
	}


	@Override
	public String delRoom(String strRoomId) {
		return adminDao.delRoom(strRoomId);
	}


	@Override
	public List<HotelDto> viewListOfHotels() {
		return adminDao.viewListOfHotels();
	}


	@Override
	public List<BookingDto> viewBookingsByHotel(String strHotelId) {
		return adminDao.viewBookingsByHotel(strHotelId);
	}


	@Override
	public List<BookingDto> viewBookingsByDate(String strDate) {
		return adminDao.viewBookingsByDate(strDate);
	}


	@Override
	public List<UserDto> viewListOfCustomers() {
		return adminDao.viewListOfCustomers();
	}


	@Override
	public List<UserDto> viewListOfHotelEmployees() {
		return adminDao.viewListOfHotelEmployees();
	}


	@Override
	public String updateHotelAddress(String strHotelId,String hotelAddress) {
		return adminDao.updateHotelAddress(strHotelId,hotelAddress);
	}


	@Override
	public String updateHotelDescription(String strHotelId, String hotelDescription) {
		return adminDao.updateHotelDescription(strHotelId,hotelDescription);
	}


	@Override
	public String updateHotelAvgRatePerNight(String strHotelId, String strHotelAvgRatePerNight) {
		return adminDao.updateHotelAvgRatePerNight(strHotelId,strHotelAvgRatePerNight);
	}


	@Override
	public String updateHotelPhone(String strHotelId, String hotelPhone1) {
		return adminDao.updateHotelPhone(strHotelId,hotelPhone1);
	}


	@Override
	public String updateHotelEmail(String strHotelId, String hotelEmail) {
		return adminDao.updateHotelEmail(strHotelId,hotelEmail);
	}


	@Override
	public String updateRoomType(String strRoomId, String roomType) {
		return adminDao.updateRoomType(strRoomId,roomType);
	}


	@Override
	public String updateRoomPerNightRate(String strRoomId, String strPerNightRate) {
		return adminDao.updateRoomPerNightRate(strRoomId,strPerNightRate);
	}


	@Override
	public String updateRoomAvailability(String strRoomId, String strAvailability) {
		return adminDao.updateRoomAvailability(strRoomId,strAvailability);
	}



}
