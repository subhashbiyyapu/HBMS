package com.cg.hbms.service;


import java.util.regex.Pattern;

public class ValidationImpl implements Validation{

	@Override
	public boolean isValidAlphanumericInput(String input) {
		String pattern="[a-zA-Z0-9 ]*$";
		if(Pattern.matches(pattern, input))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean isValidAlphabeticInput(String input) {
		String pattern="[a-zA-Z]*$";
		if(Pattern.matches(pattern, input))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean isValidNumericInput(String input) {
		String pattern="[0-9]*$";
		if(Pattern.matches(pattern, input))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean isValidAmount(String input) {
		String pattern="^[0-9]+(\\.[0-9]+)?$";
		if(Pattern.matches(pattern, input))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean isValidRating(String input) {
		String pattern="[0-5]+(\\.[0-9]+)?";
		if(Pattern.matches(pattern, input))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean isValidEmailId(String input) {
		Pattern pattern=Pattern.compile("[A-Z0-9._]+@[A-Z]+\\.[A-Z]",Pattern.CASE_INSENSITIVE);
		if(pattern.matcher(input).find())
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean isValidRoomNumber(String input) {
		String pattern="^[A-Z0-9]*$";
		if(Pattern.matches(pattern, input))
			return true;
		return false;
	}

	@Override
	public boolean isValidDate(String input) {
		Pattern pattern=Pattern.compile("[0-9]+-[0-9]+-[0-9]");
		if(pattern.matcher(input).find())
		{
			String[] date=input.split("-");
			int year=Integer.parseInt(date[0]);
			int month=Integer.parseInt(date[1]);
			int day=Integer.parseInt(date[2]);
			if(date[0].length()==4 && date[1].length()==2 && date[2].length()==2 && year>0 && month>=0 && month<=12 && day>0 && day<=31)
			{
				return true;
			}	
		}
		return false;
	}

	@Override
	public boolean isValidDate(int year, int month, int day) {
		if(year<=0 || month>12 || month<=0 || day<=0 ||day>31)
		{
			return false;
		}
		else
		{

		return true;
		}
		
	}


}
