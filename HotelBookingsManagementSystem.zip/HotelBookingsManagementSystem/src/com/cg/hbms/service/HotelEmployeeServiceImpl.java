package com.cg.hbms.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

import com.cg.hbms.dao.HotelEmployeeDao;
import com.cg.hbms.dao.HotelEmployeeDaoImpl;
import com.cg.hbms.dao.StaticDb;
import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.dto.UserDto;
import com.cg.hbms.exception.NoRoomsAvailableException;

public class HotelEmployeeServiceImpl implements HotelEmployeeService {

	HotelEmployeeDao hdao = new HotelEmployeeDaoImpl();
	@Override
	public HashMap<Integer, RoomDto> displayRooms(int hotelId, LocalDate fromDate, LocalDate toDate) {

		List<BookingDto> bookList = hdao.fetchBookingdetails(hotelId);
		List<RoomDto> roomList = hdao.fetchRoomsByHotelId(hotelId);
		HashMap<Integer, RoomDto> roomHashMap = new HashMap<Integer, RoomDto>();
		if (bookList == null) {

		} else {

			for (RoomDto room : roomList) {
				for (BookingDto book : bookList) {
					if (room.getRoomId().equals(book.getRoomId())) {
						if (fromDate.isBefore(book.getBookedFrom()) && (toDate.isBefore(book.getBookedFrom()) || toDate.isEqual(book.getBookedFrom()))) 
						{
							room.setAvailability(true);
						}

						else if (fromDate.isAfter(book.getBookedTo()) || fromDate.isEqual(book.getBookedTo()))
						{
							room.setAvailability(true);

						} 
						else {
							
							room.setAvailability(false);
							break;
						}
					}
				}

			}
		}
		for (RoomDto room : roomList) {
			roomHashMap.put(room.getRoomId(), room);
		}
      
		return roomHashMap;
	}
@Override
	public HashMap<Integer, RoomDto> displayRoomsBasedOnType(int hotelId, LocalDate fromDate, LocalDate toDate,
			int type) throws NoRoomsAvailableException {
		String roomType;
		if (type == 1) {
			roomType = "Ac";
		} else {
			roomType = "NonAc";

		}

		List<BookingDto> bookList = hdao.fetchBookingdetails(hotelId);
		List<RoomDto> roomList = hdao.fetchRoomsByHotelId(hotelId);
		HashMap<Integer, RoomDto> roomHashMap = new HashMap<Integer, RoomDto>();

		if (bookList == null) {

		} else {
			
			for (RoomDto room : roomList) {
				
				if (room.getRoomType().equals(roomType)) {
					for (BookingDto book : bookList) {
						
						
						if (room.getRoomId().equals(book.getRoomId()))
						{
					
							if (fromDate.isBefore(book.getBookedFrom()) && (toDate.isBefore(book.getBookedFrom())
									|| toDate.isEqual(book.getBookedFrom()))) {
								
								room.setAvailability(true);
							}

							else if (fromDate.isAfter(book.getBookedTo()) || fromDate.isEqual(book.getBookedTo())) {
								
								room.setAvailability(true);

							} else {
								
								room.setAvailability(false);
								break;
							}
						}
					}
				}

			}
		}

	
		for (RoomDto room : roomList) {
			if (room.getRoomType().equals(roomType) && room.isAvailability() == true) {
				roomHashMap.put(room.getRoomId(), room);
			}
		}
		if (roomHashMap.isEmpty()) {
			throw new NoRoomsAvailableException();
		}
		return roomHashMap;
	}

	@Override
	public String addBookingRecord(BookingDto bookingObj) {
		Boolean flag = hdao.insertInToBookingTable(bookingObj);
		if (flag)
			return "Booking Finished";
		else
			return "Booking error";
	}

	@Override
	public List<BookingDto> displayTransactionsOfThehotelEmployee(int hotelId, int userId) {
		List<BookingDto> bookingList = hdao.fetchBookingdetails(hotelId);
		ListIterator<BookingDto> itr = bookingList.listIterator();
		
		//integre wrapper
		while (itr.hasNext()) {
			if (((BookingDto) itr.next()).getUserId() != userId) {
				itr.remove();
			}
		}

		return (ArrayList<BookingDto>) bookingList;
	}

	@Override
	public Boolean validateDate(LocalDate fromDate, LocalDate toDate) {
		if (toDate.isAfter(fromDate)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int validateNoOfDays(LocalDate fromDate, LocalDate toDate) {
		int numDays = Period.between(fromDate, toDate).getDays();
		if (numDays > 7)
			return 0;
		else
			return numDays;

	}

	@Override
	public Boolean validatefromDate(LocalDate fromDate) {
		if (fromDate.isEqual(LocalDate.now()) || fromDate.isAfter(LocalDate.now())) {
			return true;
		} else
			return false;
	}

	@Override
	public String authenticateHotelEmployee(String userName, String password) {
		int userId=fetchUserIdBasedOnName(userName);
	
		UserDto userObj = hdao.fetchUserDetails(userId);
		Boolean validUserFlag = validateUserId(userId);
		if (validUserFlag == false) {
			return "invalidUser";
		}
		String pwd = userObj.getPassword();
		if (password.equals(pwd)) {
			return userObj.getHotelId().toString();
		} else {
			return "incorrectPassword";
		}

	}

	@Override
	public Boolean validateUserId(int userId) {
		if (hdao.fetchUserDetails(userId) == null || !hdao.fetchUserDetails(userId).getRole().equals("HE"))
			return false;
		else
			return true;
	}

	
	
	
	@Override
	public Boolean validatePassword(int userId, String oldPassword) {
		UserDto user=hdao.fetchUserDetails(userId);
		if(user.getPassword().equals(oldPassword))
			return true;
		else
			return false;
	}

	@Override
	public Boolean changePassword(int userId, String newPassword) {
		return hdao.updateUserDetails(userId,  newPassword);
	
	}

	@Override
	public int fetchUserIdBasedOnName(String userName) {
		
		return   hdao.fetchUserIdBasedOnName(userName);
	}

}
