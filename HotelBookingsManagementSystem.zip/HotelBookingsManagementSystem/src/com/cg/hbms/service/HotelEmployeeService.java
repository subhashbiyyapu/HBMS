package com.cg.hbms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.hbms.dto.BookingDto;
import com.cg.hbms.dto.RoomDto;
import com.cg.hbms.dto.UserDto;
import com.cg.hbms.exception.NoRoomsAvailableException;



public interface HotelEmployeeService {
	//String enableOrdisable(String room_name);
HashMap<Integer,RoomDto>  displayRooms(int hoteld,LocalDate bookedFrom,LocalDate bookedTo);
HashMap<Integer,RoomDto>  displayRoomsBasedOnType(int hoteld,LocalDate bookedFrom,LocalDate bookedTo,int RoomType) throws NoRoomsAvailableException;
  String  addBookingRecord(BookingDto bookingObj);
 List<BookingDto>  displayTransactionsOfThehotelEmployee(int hotelId,int userId);
  Boolean validateDate(LocalDate fromDate,LocalDate toDate);
 int validateNoOfDays(LocalDate fromDate,LocalDate toDate);
 Boolean validatefromDate(LocalDate fromDate);
String authenticateHotelEmployee(String userId,String password);
 Boolean validateUserId(int userId);
}
